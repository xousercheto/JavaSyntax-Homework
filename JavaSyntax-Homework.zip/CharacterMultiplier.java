import java.util.Scanner;

public class CharacterMultiplier {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] str = scanner.nextLine().split(" ");
        System.out.println(characterCodesMultiplied(str[0], str[1]));
    }

    private static int characterCodesMultiplied(String str1, String str2){
        int longerLength = Math.max(str1.length(), str2.length());
        int sum = 0;
        for (int i = 0; i < longerLength ; i++) {
            int char1 = 1;
            int char2 = 1;
            if (i < str1.length()){
                char1 = str1.charAt(i);
            }
            if (i < str2.length()){
                char2 = str2.charAt(i);
            }
            sum += char1 * char2;
        }
        return sum;
    }
}
