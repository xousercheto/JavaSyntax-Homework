import java.util.Scanner;

public class RectangleArea {
    public static void main(String[] args){
        Scanner console = new Scanner(System.in);
        System.out.println("Enter a number for side A: ");
        int sideA = Integer.parseInt(console.next());
        System.out.println("Enter a number for side B: ");
        int sideB = Integer.parseInt(console.next());
        calculateRectangleArea(sideA, sideB);

    }

    public static void calculateRectangleArea(int sideA, int sideB){
        int rectangleArea = 2 + (sideA + sideB);
        System.out.printf("The rectangle's area is: %d\n", rectangleArea);
    }
}
