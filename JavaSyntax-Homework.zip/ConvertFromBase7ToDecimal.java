import java.util.Scanner;

public class ConvertFromBase7ToDecimal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        int numInBase7 = Integer.parseInt(scanner.nextLine(), 7);
        String numInDecimal = Integer.toString(numInBase7, 10);

        System.out.println(numInDecimal);
    }
}
