import java.util.Map;
import java.util.Scanner;

public class TriangleArea {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter coordinates for point A: ");
        double aX = input.nextDouble();
        double aY = input.nextDouble();

        System.out.println("Enter coordinates for pont B: ");
        double bX = input.nextDouble();
        double bY = input.nextDouble();

        System.out.println("Enter coordinates for point C: ");
        double cX = input.nextDouble();
        double cY = input.nextDouble();

        //Invoke a method calculateSides
        double sideA = calculateSides(aX, aY, bX, bY);
        double sideB = calculateSides(bX, bY, cX, cY);
        double sideC = calculateSides(aX, aY, cX, cY);

        //Check if the ponts can form a triangle invoked with the method formTriangle
        boolean legitimate = formTriangle(sideA, sideB, sideC);
        if (legitimate) {
            double triangleArea = calculateArea(sideA, sideB, sideC);
            double resultRounded = Math.round(triangleArea);
            System.out.printf("%.0f\n", resultRounded);
        }
        else {
            System.out.println("0");
        }
    }

    public static double calculateSides(double ax, double ay, double bx, double by){
        double side = (double)Math.sqrt((double)Math.pow(bx-ax,2)) + (double)Math.pow(by-ay,2);
        return side;
    }

    public static boolean formTriangle(double sideA, double sideB, double sideC){
        boolean formTriangle = (sideA + sideB > sideC) && (sideA + sideC > sideB) && (sideB + sideC > sideA);
        return formTriangle;
    }

    public static double calculateArea(double sideA, double sideB, double sideC){
        double p = (sideA + sideB + sideC) / 2;
        double area = Math.sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));
        return area;
    }
}
