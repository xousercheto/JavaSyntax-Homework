import java.util.Scanner;

public class GetFirstOddOrEvenElements {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        String[] elements = scanner.nextLine().split(" ");
        int remainder = 0;

        String[] arguments = scanner.nextLine().split(" ");
        switch (arguments[2]){
            case "odd": remainder = 1; break;
            case "even": remainder = 0; break;
        }

        int count = 0;
        int elementIndex = 0;

        while (count < Integer.parseInt(arguments[1]) && elementIndex < elements.length){
            int num = Integer.parseInt(elements[elementIndex]);
            if (num % 2 == remainder){
                System.out.print(num + " ");
                count++;
            }
            elementIndex++;
        }
    }
}
