import java.util.Scanner;

public class ConvertFromDecimalSystemToBase7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int numInDecimal = Integer.parseInt(input.next(), 10);
        String numBase7 = Integer.toString(numInDecimal, 7);

        System.out.println(numInDecimal);
    }
}
